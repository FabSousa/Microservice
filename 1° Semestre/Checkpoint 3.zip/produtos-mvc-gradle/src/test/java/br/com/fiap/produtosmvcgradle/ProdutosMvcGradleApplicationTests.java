package br.com.fiap.produtosmvcgradle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProdutosMvcGradleApplicationTests {

	@Test
	void contextLoads() {
	}

}
