package br.com.fiap.mspedidos.model;

public enum Status {

    CRIADO,
    CONFIRMADO,
    ENTREGUE,
    CANCELADO,
    PAGO,
    PRONTO

}
