package br.com.fiap.fabio89291.fabio89291;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Fabio89291ApplicationTests {

	@Test
	void contextLoads() {
	}

}
