package br.com.fiap.fabio89291.fabio89291;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Fabio89291Application {

	public static void main(String[] args) {
		SpringApplication.run(Fabio89291Application.class, args);
	}

}
