package br.com.fiap.fabio89291.fabio89291.dto;

import br.com.fiap.fabio89291.fabio89291.modelFabio89291.StatusFabio89291;

public class StatusDTOFabio89291 {
    private StatusFabio89291 status;

    public StatusFabio89291 getStatus() {
        return status;
    }
}
