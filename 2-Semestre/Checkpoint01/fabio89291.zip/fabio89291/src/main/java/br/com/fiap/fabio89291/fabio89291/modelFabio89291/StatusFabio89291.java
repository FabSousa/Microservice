package br.com.fiap.fabio89291.fabio89291.modelFabio89291;

public enum StatusFabio89291 {
    CANCELADO,
    PAGO,
    ENTREGE,
    CONFIRMADO,
    PRNTO
}