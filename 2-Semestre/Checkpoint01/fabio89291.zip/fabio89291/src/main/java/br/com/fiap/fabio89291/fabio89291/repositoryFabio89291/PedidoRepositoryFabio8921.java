package br.com.fiap.fabio89291.fabio89291.repositoryFabio89291;

import br.com.fiap.fabio89291.fabio89291.modelFabio89291.PedidoFabio89291;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PedidoRepositoryFabio8921 extends JpaRepository<PedidoFabio89291, Long> {
}
