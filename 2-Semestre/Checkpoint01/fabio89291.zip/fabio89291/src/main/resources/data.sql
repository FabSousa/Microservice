INSERT INTO tb_pedido_fabio89291(data_hora, status) VALUES('2023-07-19',
'CONFIRMADO');
INSERT INTO tb_item_do_pedido_fabio89291(quantidade, descricao, pedido_id)
VALUES(1, 'Smart TV Samsung', 1);

INSERT INTO tb_pedido_fabio89291(data_hora, status) VALUES('2023-09-04',
'PAGO');
INSERT INTO tb_item_do_pedido_fabio89291(quantidade, descricao, pedido_id)
VALUES(1, 'Smartphone Sansung', 2);
INSERT INTO tb_item_do_pedido_fabio89291(quantidade, descricao, pedido_id)
VALUES(1, 'Notebook Apple', 2);